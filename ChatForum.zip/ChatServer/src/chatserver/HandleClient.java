/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatserver;
import java.awt.Image;
import java.util.*;
import java.io.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class HandleClient implements Runnable {

    private Socket socket;
    ObjectInputStream objectInputStream;

    public HandleClient(Socket socket) {
        this.socket = socket;
    }

    public void run() {
        while (true) {
           try{
                try {
                    objectInputStream = new ObjectInputStream(socket.getInputStream());
                } catch (IOException e) {
                    System.out.println("Break");
                    break;
                }
                String[] s = (String[]) objectInputStream.readObject();
                //Message message;
                //message= (Message)objectInputStream.readObject();
                System.out.println("Message received");
                //System.out.println(s[0]+s[1]+s[2]+s[3]);
                Class.forName("com.mysql.cj.jdbc.Driver");
                String url = "jdbc:mysql://localhost:3306/chat?autoReconnect=true&useSSL=false";
                System.out.println("89");
                Connection connection = DriverManager.getConnection(url, "root", "nikhil");
                System.out.println("123");
                if (s[0].equals("signup")) {
                    //teacher signup
                    System.out.println("SignUp1");
                    String query1 = "INSERT INTO user (USERNAME,PASSWORD,NAME,IMAGE) VALUES(?,?,?,?);";
                    PreparedStatement preStat = connection.prepareStatement(query1);
                    //preStat.setInt(1, 1);
                    preStat.setString(1, s[1]);
                    preStat.setString(2, s[2]);
                    preStat.setString(3, s[3]);
                    InputStream is = null;
                    try{
                        is = new FileInputStream(new File(s[4]));
                    }catch(Exception e){
                        System.out.println(e);
                    }
                    preStat.setBlob(4, is);
                    preStat.executeUpdate();
                    System.out.println("SignUp");
                    /*System.out.println("Sign Up Teacher of Teacher Completed");
                    String query2 = "SELECT * FROM teacher;";
                    preStat = connection.prepareStatement(query2);
                    ResultSet result = preStat.executeQuery();
                    while (result.next()) {
                        String un = result.getString("username");
                        String ps = result.getString("password");
                        String n = result.getString("name");
                        System.out.println("Name - " + n);
                        System.out.println("username - " + un);
                        System.out.println("Password - " + ps);
                    }*/
                    }
                 else if (s[0].equals("login")) {
                    //login teacher
                    int flag = 0;
                    try{
                    String query2 = "SELECT * FROM user;";
                    PreparedStatement preStat = connection.prepareStatement(query2);
                    //preStat.setMaxRows(1);
                    ResultSet result = preStat.executeQuery();
                    while(result.next()){
                    if ((result.getString("USERNAME").equalsIgnoreCase(s[1]) && result.getString("PASSWORD").equalsIgnoreCase(s[2]))) {
                        flag = 1;
                    }
                    }
                    if(flag==1){
                    
                        //redirect
                        ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
                        objectOutputStream.writeObject("verified");
                    } 
                    else {
                        ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
                        objectOutputStream.writeObject("not verified");
    
                    }
                    }catch(Exception e){
                        e.printStackTrace();
                        System.out.println("Incatch");
                    }
                }
                 else if(s[0].equals("giveDetail")){
                     try{
                     String username = s[1];
                     String query2 = "SELECT * FROM user WHERE USERNAME=?;";
                     PreparedStatement preStat = connection.prepareStatement(query2);
                    //preStat.setMaxRows(1);
                    preStat.setString(1, username);
                     ResultSet result = preStat.executeQuery();
                     if(result.next()){
                             try{
                                 DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                                 byte[] img = result.getBytes("Image");
                                 System.out.println(img.length);
                                 dos.writeInt(img.length);
                                 dos.write(img);
                                 dos.flush();
                                 //break;
                             }catch(Exception e){
                                 e.printStackTrace();
                                 System.out.println("Detail");
                             }
                         
                     } 
                     }catch(Exception e){
                         //System.out.println(e)
                         e.printStackTrace();
                     }
                 
                 }
                 else if(s[0].equals("chat")){
                    try{ 
                        String query = "INSERT INTO chatbox (name,message,time) VALUES(?,?,?);";     
                        PreparedStatement preStat = connection.prepareStatement(query);
                        preStat.setString(1, s[1]);
                        preStat.setString(2, s[2]);
                        preStat.setString(3, s[3]);
                        preStat.executeUpdate();
                        query = "SELECT * FROM chatbox;";
                        preStat = connection.prepareStatement(query);
                        ResultSet result = preStat.executeQuery();
                        result.last();
                        int countRow = result.getRow();
                        result.beforeFirst();
                        //String uname,msg,time;
                        String[][] table = new String[countRow][3];
                        while(result.next()){
                            table[--countRow][0] = result.getString("name");
                            table[countRow][1] = result.getString("message");
                            table[countRow][2] = result.getString("time");
                        }
                        ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
                        objectOutputStream.writeObject(table);
                    }catch(Exception e){
                        e.printStackTrace();
                    }    
                }
                else if(s[0].equals("giveTable")){
                    try{ 
                        String query = "SELECT * FROM chatbox;";
                        PreparedStatement preStat = connection.prepareStatement(query);
                        ResultSet result = preStat.executeQuery();
                        result.last();
                        int countRow = result.getRow();
                        result.beforeFirst();
                        //String uname,msg,time;
                        String[][] table = new String[countRow][3];
                        while(result.next()){
                            table[--countRow][0] = result.getString("name");
                            table[countRow][1] = result.getString("message");
                            table[countRow][2] = result.getString("time");
                        }
                        ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
                        objectOutputStream.writeObject(table);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                
                }
                 
                 
                
        }
           catch(Exception e)
           {
               
           }
        }
    }
}